## Simulador de Gestor de Procesos para Sistemas Operativos

Simulador basico de un gestor de procesos que implementa los conceptos fundamentales vistos en clase

## Informacion del Curso 

- `Materia`: Sistemas Operativos 
- `Institucion`: Universidad Autonoma de Tamaulipas. Facultad de Ingenieria "Arturo Narro Siller"
- `Semestre`: Sexto Semestre de 2025
- `Profesor`: Muñoz Quintero Dante Adolfo

## Integrantes del Equipo
- Martinez Acuña Brandon
- Diaz Villarreal Celine Michelle
- Ibarra Loredo Juan Jesus
- Saldaña Nieto Pedro Daniel
